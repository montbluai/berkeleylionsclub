
  # Berkeley Lions Club New Official Website

  This is a code bundle for Berkeley Lions Club New Official Website. The original project is available at https://www.figma.com/design/WGOrHd9y9KRxElm6k9PufX/Berkeley-Lions-Club-New-Official-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  